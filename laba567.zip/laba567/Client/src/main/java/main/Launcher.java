package main;

public class Launcher {
    public static void main(String[] args) {
        // Просто перенаправляем запуск в ваш основной класс
        MainApp.main(args);
    }
}