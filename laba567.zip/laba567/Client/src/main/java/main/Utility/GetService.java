package main.Utility;

import com.google.gson.Gson;
import main.Enums.RequestType;
import main.Models.TCP.Request;
import main.Models.TCP.Response;

import java.io.IOException;

public class GetService<T> {
    final Class<T> classType;

    public GetService(Class<T> classType) {
        this.classType = classType;
    }

    public String getEntities(RequestType requestType) {
        Request request = new Request();
        request.setRequestMessage("");
        request.setRequestType(requestType);
        ClientSocket.getInstance().getOut().println(new Gson().toJson(request));
        ClientSocket.getInstance().getOut().flush();
        String answer = null;
        try {
            answer = ClientSocket.getInstance().getInStream().readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Response response = new Gson().fromJson(answer, Response.class);
        return response.getResponseData();
    }

    public String sendRequest(RequestType requestType, Object entity) {
        Request request = new Request();
        request.setRequestMessage(new Gson().toJson(entity));
        request.setRequestType(requestType);
        ClientSocket.getInstance().getOut().println(new Gson().toJson(request));
        ClientSocket.getInstance().getOut().flush();
        String answer = null;
        try {
            answer = ClientSocket.getInstance().getInStream().readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Response response = new Gson().fromJson(answer, Response.class);
        return response.getResponseData();
    }

    public String sendRequest(server.Enums.RequestType requestType, T params) {
        return "";
    }
}