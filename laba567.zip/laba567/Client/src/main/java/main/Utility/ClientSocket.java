package main.Utility;

import main.Models.Entities.User;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientSocket {
    private static ClientSocket SINGLE_INSTANCE;
    private User user;
    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;

    private ClientSocket() {
        try {
            // Убедись, что сервер запущен на этом порту
            socket = new Socket("localhost", 5555);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            // autoflush = true для немедленной отправки данных
            out = new PrintWriter(socket.getOutputStream(), true);
        } catch (Exception e) {
            System.err.println("Не удалось подключиться к серверу: " + e.getMessage());
        }
    }

    // В классе ClientSocket.java
    public static synchronized ClientSocket getInstance() {
        if (SINGLE_INSTANCE == null) {
            SINGLE_INSTANCE = new ClientSocket();
        }
        // Если прошлая попытка не удалась (socket == null), пробуем еще раз
        if (SINGLE_INSTANCE.getOut() == null) {
            SINGLE_INSTANCE = new ClientSocket();
        }
        return SINGLE_INSTANCE;
    }

    public Socket getSocket() { return socket; }
    public BufferedReader getInStream() { return in; }
    public PrintWriter getOut() { return out; }
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
}