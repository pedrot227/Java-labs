package main.Enums;

public enum Roles {
    Администратор,
    Бухгалтер,
    Сотрудник
}