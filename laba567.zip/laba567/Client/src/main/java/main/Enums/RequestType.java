package main.Enums;

public enum RequestType {
    LOGIN,
    REGISTER,
    // Сотрудники
    ADD_EMPLOYEE,
    UPDATE_EMPLOYEE,
    DELETE_EMPLOYEE,
    GET_EMPLOYEE,
    GETALL_EMPLOYEES,
    // Отделы
    GETALL_DEPARTMENTS,
    ADD_DEPARTMENT,
    UPDATE_DEPARTMENT,
    DELETE_DEPARTMENT,
    // Должности
    GETALL_POSITIONS,
    ADD_POSITION,
    UPDATE_POSITION,
    DELETE_POSITION,
    // Расчёты
    CALCULATE_SALARY,
    CALCULATE_SALARY_BULK,
    // Выплаты
    GETALL_PAYMENTS,
    GET_PAYMENTS_BY_EMPLOYEE,
    GET_PAYMENTS_BY_PERIOD,
    UPDATE_PAYMENT_STATUS,
    GENERATE_PAYMENTS,       // <--- ДОБАВЛЕНО ДЛЯ РАБОТЫ ОБНОВЛЕНИЯ
    // Отчёты
    GET_PAYROLL_SUMMARY,
    EXPORT_CSV,
    GENERATE_MONTHLY_REPORT,
    FORECAST_PAYROLL,
    // Пользователи
    GETALL_USERS,
    DELETE_USER,
    UPDATE_USER_ROLE
}