package main.Models.Entities;

/**
 * Класс сущности "Роль пользователя".
 */
public class Role extends AbstractEntity {
    private String roleName;


    public Role() {
        super();
    }

    public Role(int id, String roleName) {
        super(id);
        this.roleName = roleName;
    }

    public String getRoleName() { return roleName; }
    public void setRoleName(String roleName) { this.roleName = roleName; }


}