package main.Models.Entities;

/**
 * Класс сущности "Должность".
 */
public class Position extends AbstractEntity {
    private String positionName;
    private double baseSalary;
    private double hourlyRate;


    public Position() {
        super();
    }

    public Position(int id, String positionName, double baseSalary, double hourlyRate) {
        super(id);
        this.positionName = positionName;
        this.baseSalary = baseSalary;
        this.hourlyRate = hourlyRate;
    }

    // Геттеры и сеттеры
    public String getPositionName() { return positionName; }
    public void setPositionName(String positionName) { this.positionName = positionName; }

    public double getBaseSalary() { return baseSalary; }
    public void setBaseSalary(double baseSalary) { this.baseSalary = baseSalary; }

    public double getHourlyRate() { return hourlyRate; }
    public void setHourlyRate(double hourlyRate) { this.hourlyRate = hourlyRate; }



    @Override
    public String toString() {
        return positionName;
    }
}