package main.Models.Entities;

/**
 * Класс сущности "Выплата" (Расчетный лист).
 * Наследуется от AbstractEntity, что обеспечивает наличие поля id и поддержку Serializable.
 */
public class Payment extends AbstractEntity {
    private int employeeId;
    private int month;
    private int year;
    private int workedDays;
    private int totalWorkDays;
    private double bonus;
    private double totalAccrued;
    private double pensionContribution;
    private double incomeTax;
    private double taxDeduction;
    private double netSalary;
    private String paymentStatus;

    // Дополнительные поля для отображения в таблицах интерфейса (UI)
    private String employeeFullName;
    private String positionName;
    private String departmentName;

    // Пустой конструктор для работы GSON/сериализации
    public Payment() {
        super();
    }

    // Если тебе понадобится конструктор со всеми полями, используй super(id)
    public Payment(int id, int employeeId, int month, int year) {
        super(id);
        this.employeeId = employeeId;
        this.month = month;
        this.year = year;
    }

    // Геттеры и сеттеры специфичные для Payment
    public int getEmployeeId() { return employeeId; }
    public void setEmployeeId(int employeeId) { this.employeeId = employeeId; }

    public int getMonth() { return month; }
    public void setMonth(int month) { this.month = month; }

    public int getYear() { return year; }
    public void setYear(int year) { this.year = year; }

    public int getWorkedDays() { return workedDays; }
    public void setWorkedDays(int workedDays) { this.workedDays = workedDays; }

    public int getTotalWorkDays() { return totalWorkDays; }
    public void setTotalWorkDays(int totalWorkDays) { this.totalWorkDays = totalWorkDays; }

    public double getBonus() { return bonus; }
    public void setBonus(double bonus) { this.bonus = bonus; }

    public double getTotalAccrued() { return totalAccrued; }
    public void setTotalAccrued(double totalAccrued) { this.totalAccrued = totalAccrued; }

    public double getPensionContribution() { return pensionContribution; }
    public void setPensionContribution(double pensionContribution) { this.pensionContribution = pensionContribution; }

    public double getIncomeTax() { return incomeTax; }
    public void setIncomeTax(double incomeTax) { this.incomeTax = incomeTax; }

    public double getTaxDeduction() { return taxDeduction; }
    public void setTaxDeduction(double taxDeduction) { this.taxDeduction = taxDeduction; }

    public double getNetSalary() { return netSalary; }
    public void setNetSalary(double netSalary) { this.netSalary = netSalary; }

    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }

    public String getEmployeeFullName() { return employeeFullName; }
    public void setEmployeeFullName(String employeeFullName) { this.employeeFullName = employeeFullName; }

    public String getPositionName() { return positionName; }
    public void setPositionName(String positionName) { this.positionName = positionName; }

    public String getDepartmentName() { return departmentName; }
    public void setDepartmentName(String departmentName) { this.departmentName = departmentName; }
}