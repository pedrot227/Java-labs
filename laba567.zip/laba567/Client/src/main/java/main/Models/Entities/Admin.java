package main.Models.Entities;

/**
 * Класс сущности "Администратор".
 * Наследуется от User для расширения иерархии (8-й класс).
 */
public class Admin extends User {

    public Admin() {
        super();
    }

    public Admin(int id, String login, String password, int roleId) {
        super(id, login, password, roleId);
    }

    @Override
    public String toString() {
        return "Администратор: " + getLogin();
    }
}