package main.Models.TCP;

import main.Enums.ResponseStatus;

public class Response {
    private ResponseStatus responseStatus;
    private String responseMessage;
    private String responseData;

    public Response() {}

    // Конструктор для ТРЕХ параметров (уже есть)
    public Response(ResponseStatus responseStatus, String responseMessage, String responseData) {
        this.responseStatus = responseStatus;
        this.responseMessage = responseMessage;
        this.responseData = responseData;
    }

    // ДОБАВЬ ЭТОТ КОНСТРУКТОР (для ДВУХ параметров)
    public Response(ResponseStatus responseStatus, String responseData) {
        this.responseStatus = responseStatus;
        this.responseData = responseData;
    }

    public ResponseStatus getResponseStatus() { return responseStatus; }
    public void setResponseStatus(ResponseStatus responseStatus) { this.responseStatus = responseStatus; }

    public String getResponseMessage() { return responseMessage; }
    public void setResponseMessage(String responseMessage) { this.responseMessage = responseMessage; }

    public String getResponseData() { return responseData; }
    public void setResponseData(String responseData) { this.responseData = responseData; }
}