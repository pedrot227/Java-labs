package main.Models.Entities;

/**
 * Класс сущности "Отдел".
 */
public class Department extends AbstractEntity {
    private String departmentName;
    private String headFullName;


    public Department() {
        super();
    }

    public Department(int id, String departmentName, String headFullName) {
        super(id);
        this.departmentName = departmentName;
        this.headFullName = headFullName;
    }

    // Геттеры и сеттеры
    public String getDepartmentName() { return departmentName; }
    public void setDepartmentName(String departmentName) { this.departmentName = departmentName; }

    public String getHeadFullName() { return headFullName; }
    public void setHeadFullName(String headFullName) { this.headFullName = headFullName; }



    @Override
    public String toString() {
        return departmentName;
    }
}