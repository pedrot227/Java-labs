package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.Objects;

public class AdminDashboardController {

    @FXML private Button btnLogout;
    @FXML private Button btnEmployees;
    @FXML private Button btnDepartments;
    @FXML private Button btnPositions;
    @FXML private Button btnPayments;

    @FXML
    public void initialize() {
        if (btnDepartments != null) btnDepartments.setDisable(false);
        if (btnPositions != null) btnPositions.setDisable(false);
    }

    @FXML
    public void openEmployeeManagement(ActionEvent event) { loadScene("/EmployeeManagement.fxml", event); }

    @FXML
    public void openDepartmentManagement(ActionEvent event) { loadScene("/DepartmentManagement.fxml", event); }

    @FXML
    public void openPositionManagement(ActionEvent event) { loadScene("/PositionManagement.fxml", event); }

    @FXML
    public void openPaymentHistory(ActionEvent event) { loadScene("/PaymentHistory.fxml", event); }

    // --- НОВЫЙ МЕТОД ---
    @FXML
    public void openSalaryCalculation(ActionEvent event) {
        // Убедись, что название файла совпадает с твоим (например, /salary_calculation.fxml)
        loadScene("/SalaryCalculation.fxml", event);
    }
    // -------------------

    @FXML
    public void logout(ActionEvent event) {
        try {
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/Login.fxml")));
            stage.setScene(new Scene(root));
        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
        }
    }

    private void loadScene(String fxmlFile, ActionEvent event) {
        try {
            var resource = getClass().getResource(fxmlFile);
            if (resource == null) {
                System.err.println("Файл не найден: " + fxmlFile);
                return;
            }
            Parent root = FXMLLoader.load(resource);

            Stage newStage = new Stage();
            newStage.setScene(new Scene(root));

            // Добавил заголовок для нового окна расчета
            if (fxmlFile.contains("Employee")) newStage.setTitle("Управление сотрудниками");
            else if (fxmlFile.contains("Report")) newStage.setTitle("Сводные отчеты");
            else if (fxmlFile.contains("Payment")) newStage.setTitle("История выплат");
            else if (fxmlFile.contains("salary")) newStage.setTitle("Расчёт заработной платы"); // <-- Добавлено
            else newStage.setTitle("Справочник");

            newStage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            newStage.show();
        } catch (IOException e) {
            System.err.println("Ошибка открытия окна: " + fxmlFile);
            e.printStackTrace();
        }
    }

    @FXML
    void openReports(ActionEvent event) {
        loadScene("/Report.fxml", event);
    }
}