package controllers;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import main.Enums.RequestType;
import main.Models.Entities.Employee;
import main.Models.Entities.Payment;
import main.Utility.ClientSocket;
import main.Utility.GetService;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class EmployeeDashboardController implements Initializable {

    @FXML private Label labelWelcome;
    @FXML private TableView<Payment> tableMyPayments;
    @FXML private TableColumn<Payment, Integer> colMonth, colYear;
    @FXML private TableColumn<Payment, Double> colAccrued, colNet;
    @FXML private TableColumn<Payment, String> colStatus;
    @FXML private Button btnLogout;

    private ObservableList<Payment> paymentList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        String login = ClientSocket.getInstance().getUser().getLogin();
        labelWelcome.setText("Добро пожаловать, " + login + "!");

        colMonth.setCellValueFactory(new PropertyValueFactory<>("month"));
        colYear.setCellValueFactory(new PropertyValueFactory<>("year"));
        colAccrued.setCellValueFactory(new PropertyValueFactory<>("totalAccrued"));
        colNet.setCellValueFactory(new PropertyValueFactory<>("netSalary"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("paymentStatus"));

        tableMyPayments.setItems(paymentList);
        loadMyPayments();
    }

    private void loadMyPayments() {
        Employee dummyEmp = new Employee();
        // Берем ID текущего залогиненного пользователя
        dummyEmp.setId(ClientSocket.getInstance().getUser().getId());

        GetService<Payment> service = new GetService<>(Payment.class);
        // 1. Получаем JSON-ответ от сервера (это объект Response в виде строки)
        String rawResponse = service.sendRequest(RequestType.GET_PAYMENTS_BY_EMPLOYEE, dummyEmp);

        // 2. Распаковываем сначала сам Response
        main.Models.TCP.Response responseObj = new Gson().fromJson(rawResponse, main.Models.TCP.Response.class);

        // 3. Проверяем, что сервер прислал OK и данные не пусты
        if (responseObj.getResponseStatus() == main.Enums.ResponseStatus.OK && responseObj.getResponseData() != null) {
            Type listType = new TypeToken<List<Payment>>() {}.getType();
            // Парсим именно поле responseData, где лежит массив выплат
            List<Payment> list = new Gson().fromJson(responseObj.getResponseData(), listType);

            if (list != null) {
                paymentList.clear();
                paymentList.addAll(list);
            }
        } else {
            System.err.println("Ошибка загрузки данных: " + responseObj.getResponseMessage());
        }
    }

    public void logout(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) btnLogout.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("/Login.fxml"));
        stage.setScene(new Scene(root));
    }
}