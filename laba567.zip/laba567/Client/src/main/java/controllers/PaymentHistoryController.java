package controllers;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import main.Enums.RequestType;
import main.Models.Entities.Payment;
import main.Utility.GetService;

import java.lang.reflect.Type;
import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;

public class PaymentHistoryController implements Initializable {

    @FXML private TableView<Payment> tableHistory;
    @FXML private TableColumn<Payment, String> colEmployee;
    @FXML private TableColumn<Payment, String> colMonth;
    @FXML private TableColumn<Payment, Integer> colYear;
    @FXML private TableColumn<Payment, Double> colNet;
    @FXML private TableColumn<Payment, String> colStatus;

    private ObservableList<Payment> paymentList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        colEmployee.setCellValueFactory(new PropertyValueFactory<>("employeeFullName"));
        colMonth.setCellValueFactory(new PropertyValueFactory<>("month"));
        colYear.setCellValueFactory(new PropertyValueFactory<>("year"));
        colNet.setCellValueFactory(new PropertyValueFactory<>("netSalary"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("paymentStatus"));

        tableHistory.setItems(paymentList);
        loadHistory();
    }

    // Метод для кнопки "Обновить" — теперь он инициирует генерацию новых записей
    @FXML
    public void refreshData(ActionEvent event) {
        // Чтобы появились новые сотрудники, сначала просим сервер их сгенерировать
        GetService<Payment> service = new GetService<>(Payment.class);

        // Создаем объект-заглушку с текущей датой для генерации
        Payment params = new Payment();
        params.setMonth(LocalDate.now().getMonthValue());
        params.setYear(LocalDate.now().getYear());

        // Вызываем новый RequestType, который мы добавили в ClientHandler
        service.sendRequest(RequestType.GENERATE_PAYMENTS, params);

        loadHistory();
    }

    @FXML
    public void onPaySelectedClick(ActionEvent event) {
        Payment selected = tableHistory.getSelectionModel().getSelectedItem();

        if (selected == null) {
            showInfo("Выбор не сделан", "Выберите запись из списка.");
            return;
        }

        // Если статус уже "Выплачено", делать ничего не нужно
        if ("Выплачено".equals(selected.getPaymentStatus())) {
            showInfo("Внимание", "Эта выплата уже имеет статус 'Выплачено'.");
            return;
        }

        // Меняем статус на клиенте и отправляем на сервер
        selected.setPaymentStatus("Выплачено");

        GetService<Payment> service = new GetService<>(Payment.class);
        // Используем корректный тип запроса для смены статуса
        String responseJson = service.sendRequest(RequestType.UPDATE_PAYMENT_STATUS, selected);

        if (responseJson != null) {
            showInfo("Успех", "Статус выплаты для " + selected.getEmployeeFullName() + " изменен на 'Выплачено'.");
            loadHistory();
        } else {
            showInfo("Ошибка", "Не удалось обновить статус на сервере.");
        }
    }

    private void loadHistory() {
        GetService<Payment> service = new GetService<>(Payment.class);
        String responseJson = service.sendRequest(RequestType.GETALL_PAYMENTS, null);

        if (responseJson == null || responseJson.isEmpty() || responseJson.equalsIgnoreCase("null")) {
            paymentList.clear();
            return;
        }

        try {
            Type listType = new TypeToken<List<Payment>>() {}.getType();
            List<Payment> list = new Gson().fromJson(responseJson, listType);

            if (list != null) {
                paymentList.setAll(list);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}