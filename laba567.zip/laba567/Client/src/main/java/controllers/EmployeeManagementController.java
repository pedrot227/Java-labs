package controllers;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.StringConverter;
import main.Enums.RequestType;
import main.Models.Entities.Employee;
import main.Models.Entities.Department;
import main.Models.Entities.Position;
import main.Utility.GetService;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class EmployeeManagementController implements Initializable {

    @FXML private TableView<Employee> tableEmployees;
    @FXML private TableColumn<Employee, Integer> colId, colChildren;
    @FXML private TableColumn<Employee, String> colFirstName, colLastName, colDepartment, colPosition, colHireDate;

    @FXML private TextField txtFirstName, txtLastName, txtHireDate;

    // НОВЫЕ ПОЛЯ ДЛЯ УЧЕТНОЙ ЗАПИСИ
    @FXML private TextField txtLogin;
    @FXML private PasswordField txtPassword;

    @FXML private Spinner<Integer> spinnerChildren;
    @FXML private ComboBox<Department> comboDepartment;
    @FXML private ComboBox<Position> comboPosition;

    private ObservableList<Employee> employeeList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colFirstName.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        colLastName.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        colDepartment.setCellValueFactory(new PropertyValueFactory<>("departmentName"));
        colPosition.setCellValueFactory(new PropertyValueFactory<>("positionName"));
        colHireDate.setCellValueFactory(new PropertyValueFactory<>("hireDate"));
        colChildren.setCellValueFactory(new PropertyValueFactory<>("childrenCount"));

        spinnerChildren.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 10, 0));
        tableEmployees.setItems(employeeList);

        setupComboBoxConverters();
        loadEmployees();
        loadDictionaries();
    }

    // Метод добавления обновлен для передачи логина и пароля[cite: 1]
    @FXML
    public void addEmployee(ActionEvent actionEvent) {
        if (comboDepartment.getValue() == null || comboPosition.getValue() == null) {
            showError("Ошибка", "Выберите отдел и должность!");
            return;
        }

        // Базовая проверка на заполнение логина[cite: 1]
        if (txtLogin.getText().isEmpty() || txtPassword.getText().isEmpty()) {
            showError("Ошибка", "Заполните логин и пароль для учетной записи!");
            return;
        }

        Employee emp = new Employee();
        emp.setFirstName(txtFirstName.getText());
        emp.setLastName(txtLastName.getText());
        emp.setHireDate(txtHireDate.getText());
        emp.setChildrenCount(spinnerChildren.getValue());
        emp.setDepartmentId(comboDepartment.getValue().getId());
        emp.setPositionId(comboPosition.getValue().getId());

        // УСТАНОВКА ДАННЫХ АВТОРИЗАЦИИ[cite: 1]
        emp.setLogin(txtLogin.getText());
        emp.setPassword(txtPassword.getText());

        new GetService<>(Employee.class).sendRequest(RequestType.ADD_EMPLOYEE, emp);
        loadEmployees();
        clearFields();
    }

    private void clearFields() {
        txtFirstName.clear();
        txtLastName.clear();
        txtHireDate.clear();
        txtLogin.clear();    // Очистка новых полей[cite: 1]
        txtPassword.clear();
        spinnerChildren.getValueFactory().setValue(0);
        comboDepartment.getSelectionModel().clearSelection();
        comboPosition.getSelectionModel().clearSelection();
    }

    // --- ОСТАЛЬНЫЕ МЕТОДЫ (loadEmployees, loadDictionaries и т.д.) БЕЗ ИЗМЕНЕНИЙ ---

    private void setupComboBoxConverters() {
        comboDepartment.setConverter(new StringConverter<Department>() {
            @Override public String toString(Department d) { return d == null ? "" : d.getDepartmentName(); }
            @Override public Department fromString(String s) { return null; }
        });
        comboPosition.setConverter(new StringConverter<Position>() {
            @Override public String toString(Position p) { return p == null ? "" : p.getPositionName(); }
            @Override public Position fromString(String s) { return null; }
        });
    }

    private void loadDictionaries() {
        Gson gson = new Gson();
        String depResp = new GetService<>(Department.class).sendRequest(RequestType.GETALL_DEPARTMENTS, null);
        List<Department> departments = gson.fromJson(depResp, new TypeToken<List<Department>>(){}.getType());
        if (departments != null) comboDepartment.setItems(FXCollections.observableArrayList(departments));

        String posResp = new GetService<>(Position.class).sendRequest(RequestType.GETALL_POSITIONS, null);
        List<Position> positions = gson.fromJson(posResp, new TypeToken<List<Position>>(){}.getType());
        if (positions != null) comboPosition.setItems(FXCollections.observableArrayList(positions));
    }

    private void loadEmployees() {
        String response = new GetService<>(Employee.class).sendRequest(RequestType.GETALL_EMPLOYEES, null);
        List<Employee> list = new Gson().fromJson(response, new TypeToken<List<Employee>>() {}.getType());
        employeeList.clear();
        if (list != null) employeeList.setAll(list);
    }

    @FXML
    public void deleteEmployee(ActionEvent actionEvent) {
        Employee selected = tableEmployees.getSelectionModel().getSelectedItem();
        if (selected != null) {
            new GetService<>(Employee.class).sendRequest(RequestType.DELETE_EMPLOYEE, selected);
            loadEmployees();
        }
    }

    private void showError(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}