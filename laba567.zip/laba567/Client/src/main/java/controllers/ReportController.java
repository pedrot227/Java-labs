package controllers;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import main.Enums.RequestType;
import main.Models.Entities.Payment;
import main.Utility.GetService;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class ReportController implements Initializable {

    @FXML private ComboBox<String> comboMonth;
    @FXML private Spinner<Integer> spinnerYear;
    @FXML private Label lblTotalAccrued, lblTotalTaxes, lblTotalNet, lblEmployeeCount;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        comboMonth.setItems(FXCollections.observableArrayList(
                "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
                "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"
        ));
        comboMonth.getSelectionModel().selectFirst();
        spinnerYear.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(2020, 2030, 2026));
    }

    @FXML
    public void generateReport(ActionEvent actionEvent) {
        int month = comboMonth.getSelectionModel().getSelectedIndex() + 1;
        int year = spinnerYear.getValue();

        Payment params = new Payment();
        params.setMonth(month);
        params.setYear(year);

        GetService<Payment> service = new GetService<>(Payment.class);
        // Используем RequestType напрямую, чтобы избежать путаницы с импортами
        String responseJson = service.sendRequest(RequestType.GET_PAYMENTS_BY_PERIOD, params);

        if (responseJson == null || responseJson.isEmpty() || responseJson.equalsIgnoreCase("null")) {
            clearUI();
            return;
        }

        try {
            Type listType = new TypeToken<List<Payment>>() {}.getType();
            List<Payment> payments = new Gson().fromJson(responseJson, listType);

            if (payments != null && !payments.isEmpty()) {
                updateUI(payments);
            } else {
                clearUI();
            }
        } catch (Exception e) {
            e.printStackTrace();
            clearUI();
        }
    }

    @FXML
    public void exportToCSV(ActionEvent actionEvent) {
        int month = comboMonth.getSelectionModel().getSelectedIndex() + 1;
        int year = spinnerYear.getValue();

        Payment params = new Payment();
        params.setMonth(month);
        params.setYear(year);

        GetService<Payment> service = new GetService<>(Payment.class);
        String response = service.sendRequest(RequestType.GENERATE_MONTHLY_REPORT, params);

        showInfo("Экспорт", response != null && !response.isEmpty() ? response : "Запрос отправлен на сервер.");
    }



    private void updateUI(List<Payment> payments) {
        double totalAccrued = payments.stream().mapToDouble(Payment::getTotalAccrued).sum();
        double totalTaxes = payments.stream().mapToDouble(p -> p.getIncomeTax() + p.getPensionContribution()).sum();
        double totalNet = payments.stream().mapToDouble(Payment::getNetSalary).sum();

        lblEmployeeCount.setText(String.valueOf(payments.size()));
        lblTotalAccrued.setText(String.format("%.2f BYN", totalAccrued));
        lblTotalTaxes.setText(String.format("%.2f BYN", totalTaxes));
        lblTotalNet.setText(String.format("%.2f BYN", totalNet));
    }

    private void clearUI() {
        lblEmployeeCount.setText("0");
        lblTotalAccrued.setText("0.00 BYN");
        lblTotalTaxes.setText("0.00 BYN");
        lblTotalNet.setText("0.00 BYN");
    }

    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}