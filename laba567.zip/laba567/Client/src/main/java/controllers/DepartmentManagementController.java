package controllers;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import main.Enums.RequestType;
import main.Models.Entities.Department; // Убедись, что путь к классу Department верный
import main.Utility.GetService;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class DepartmentManagementController implements Initializable {

    @FXML private TableView<Department> tableDepartments;
    @FXML private TableColumn<Department, Integer> colId;
    @FXML private TableColumn<Department, String> colName;
    @FXML private TextField txtDeptName;

    private ObservableList<Department> departmentList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Связываем колонки с полями класса Department
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colName.setCellValueFactory(new PropertyValueFactory<>("departmentName"));

        tableDepartments.setItems(departmentList);
        loadDepartments();
    }

    private void loadDepartments() {
        GetService<Department> service = new GetService<>(Department.class);
        String response = service.sendRequest(RequestType.GETALL_DEPARTMENTS, null);
        Type listType = new TypeToken<List<Department>>() {}.getType();
        List<Department> list = new Gson().fromJson(response, listType);

        departmentList.clear();
        if (list != null) departmentList.setAll(list);
    }

    @FXML
    void addDepartment(ActionEvent event) {
        if (txtDeptName.getText().trim().isEmpty()) {
            showAlert("Ошибка", "Введите название отдела!");
            return;
        }

        Department dept = new Department();
        dept.setDepartmentName(txtDeptName.getText().trim());

        new GetService<>(Department.class).sendRequest(RequestType.ADD_DEPARTMENT, dept);
        loadDepartments();
        txtDeptName.clear();
    }

    @FXML
    void deleteDepartment(ActionEvent event) {
        Department selected = tableDepartments.getSelectionModel().getSelectedItem();
        if (selected != null) {
            new GetService<>(Department.class).sendRequest(RequestType.DELETE_DEPARTMENT, selected);
            loadDepartments();
        }
    }

    @FXML
    void backToMenu(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/AdminDashboard.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}