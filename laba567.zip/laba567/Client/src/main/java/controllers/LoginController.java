package controllers;

import com.google.gson.Gson;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import main.Enums.RequestType;
import main.Enums.ResponseStatus;
import main.Models.Entities.User;
import main.Models.TCP.Request;
import main.Models.TCP.Response;
import main.Utility.ClientSocket;

import java.io.IOException;

public class LoginController {
    @FXML private TextField textfieldLogin;
    @FXML private PasswordField passwordfieldPassword;
    @FXML private Button buttonLogin;
    @FXML private Button buttonRegister;
    @FXML private Label labelMessage;

    private final Gson gson = new Gson();

    public void loginPressed(ActionEvent actionEvent) {
        // 1. Валидация полей
        if (textfieldLogin.getText().isEmpty() || passwordfieldPassword.getText().isEmpty()) {
            showMessage("Заполните все поля", true);
            return;
        }

        try {
            // 2. Получаем экземпляр сокета и проверяем его готовность
            ClientSocket clientSocket = ClientSocket.getInstance();

            if (clientSocket.getOut() == null || clientSocket.getInStream() == null) {
                showMessage("Ошибка: Сервер недоступен", true);
                return;
            }

            // 3. Формируем данные пользователя
            User user = new User();
            user.setLogin(textfieldLogin.getText().trim());
            user.setPassword(passwordfieldPassword.getText().trim());

            // 4. Формируем и отправляем запрос
            Request request = new Request();
            request.setRequestType(RequestType.LOGIN);
            request.setRequestMessage(gson.toJson(user));

            clientSocket.getOut().println(gson.toJson(request));
            // PrintWriter с autoflush=true (как в вашем ClientSocket) отправит данные сам,
            // но для надежности можно оставить flush

            // 5. Получаем ответ от сервера
            String answer = clientSocket.getInStream().readLine();
            if (answer == null) {
                showMessage("Сервер разорвал соединение", true);
                return;
            }

            Response response = gson.fromJson(answer, Response.class);

            // 6. Обработка результата
            if (response.getResponseStatus() == ResponseStatus.OK) {
                labelMessage.setVisible(false);

                // Сохраняем данные авторизованного пользователя
                User loggedUser = gson.fromJson(response.getResponseData(), User.class);
                clientSocket.setUser(loggedUser);

                // Переход на соответствующий дашборд
                navigateToDashboard(loggedUser.getRoleName());
            } else {
                showMessage("Неверный логин или пароль", true);
            }

        } catch (IOException e) {
            e.printStackTrace();
            showMessage("Ошибка сети: " + e.getMessage(), true);
        } catch (Exception e) {
            e.printStackTrace();
            showMessage("Произошла системная ошибка", true);
        }
    }

    private void showMessage(String text, boolean isError) {
        labelMessage.setText(text);
        labelMessage.setStyle(isError ? "-fx-text-fill: red;" : "-fx-text-fill: green;");
        labelMessage.setVisible(true);
    }

    // Изменяем только этот метод, остальное в контроллере остается прежним
    private void navigateToDashboard(String role) throws IOException {
        String fxmlFile;

        // Защита от NullPointerException на строке 99
        String currentRole = (role != null) ? role : "Сотрудник";

        switch (currentRole) {
            case "Администратор":
                fxmlFile = "/AdminDashboard.fxml";
                break;
            case "Бухгалтер":
                fxmlFile = "/AccountantDashboard.fxml";
                break;
            case "Сотрудник":
            default:
                fxmlFile = "/EmployeeDashboard.fxml";
                break;
        }

        Stage stage = (Stage) buttonLogin.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource(fxmlFile));
        if (root == null) {
            throw new IOException("FXML файл не найден: " + fxmlFile);
        }
        stage.setScene(new Scene(root));
        stage.show();
    }

    public void registerPressed(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) buttonLogin.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("/Register.fxml"));
        stage.setScene(new Scene(root));
    }
}