package controllers;

import com.google.gson.Gson;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import main.Enums.RequestType;
import main.Enums.ResponseStatus;
import main.Models.Entities.User;
import main.Models.TCP.Request;
import main.Models.TCP.Response;
import main.Utility.ClientSocket;

import java.io.IOException;

public class RegisterController {
    @FXML private TextField textfieldLogin;
    @FXML private PasswordField passwordfieldPassword;
    @FXML private Label labelMessage;
    @FXML private Button buttonRegister;

    public void registerPressed(ActionEvent actionEvent) throws IOException {
        if (textfieldLogin.getText().isEmpty() || passwordfieldPassword.getText().isEmpty()) {
            labelMessage.setText("Заполните все поля");
            labelMessage.setVisible(true);
            return;
        }

        User user = new User();
        user.setLogin(textfieldLogin.getText());
        user.setPassword(passwordfieldPassword.getText());
        user.setRoleId(3); // По умолчанию регистрируем как сотрудника

        Request request = new Request(RequestType.REGISTER, new Gson().toJson(user));
        ClientSocket.getInstance().getOut().println(new Gson().toJson(request));
        ClientSocket.getInstance().getOut().flush();

        String answer = ClientSocket.getInstance().getInStream().readLine();
        Response response = new Gson().fromJson(answer, Response.class);

        if (response.getResponseStatus() == ResponseStatus.OK) {
            goBack(actionEvent);
        } else {
            labelMessage.setText(response.getResponseMessage());
            labelMessage.setVisible(true);
        }
    }

    public void goBack(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) buttonRegister.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("/Login.fxml"));
        stage.setScene(new Scene(root));
    }
}