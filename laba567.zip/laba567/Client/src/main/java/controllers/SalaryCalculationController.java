package controllers;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import main.Enums.RequestType;
import main.Models.Entities.Payment;
import main.Utility.GetService;

import java.lang.reflect.Type;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class SalaryCalculationController implements Initializable {

    @FXML private ComboBox<String> comboMonth;
    @FXML private Spinner<Integer> spinnerYear;
    @FXML private Spinner<Integer> spinnerWorkedDays;
    @FXML private Spinner<Integer> spinnerTotalDays;
    @FXML private Button buttonCalculateAll;
    @FXML private Label labelStatus;

    @FXML private TableView<Payment> tablePayments;
    @FXML private TableColumn<Payment, String> colEmployee;
    @FXML private TableColumn<Payment, String> colPosition;
    @FXML private TableColumn<Payment, Double> colAccrued;
    @FXML private TableColumn<Payment, Double> colPension;
    @FXML private TableColumn<Payment, Double> colTax;
    @FXML private TableColumn<Payment, Double> colNet;
    @FXML private TableColumn<Payment, String> colStatus;

    private ObservableList<Payment> paymentList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Инициализация месяцев
        comboMonth.setItems(FXCollections.observableArrayList(
                "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
                "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"
        ));
        comboMonth.getSelectionModel().selectFirst();

        // Инициализация спиннеров
        spinnerYear.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(2020, 2030, 2026));
        spinnerWorkedDays.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 31, 22));
        spinnerTotalDays.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 31, 22));

        // Настройка колонок таблицы
        colEmployee.setCellValueFactory(new PropertyValueFactory<>("employeeFullName"));
        colPosition.setCellValueFactory(new PropertyValueFactory<>("positionName"));
        colAccrued.setCellValueFactory(new PropertyValueFactory<>("totalAccrued"));
        colPension.setCellValueFactory(new PropertyValueFactory<>("pensionContribution"));
        colTax.setCellValueFactory(new PropertyValueFactory<>("incomeTax"));
        colNet.setCellValueFactory(new PropertyValueFactory<>("netSalary"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("paymentStatus"));

        tablePayments.setItems(paymentList);
    }

    public void calculateAllPressed(ActionEvent actionEvent) {
        int month = comboMonth.getSelectionModel().getSelectedIndex() + 1;
        int year = spinnerYear.getValue();
        int workedDays = spinnerWorkedDays.getValue();
        int totalDays = spinnerTotalDays.getValue();

        Payment params = new Payment();
        params.setMonth(month);
        params.setYear(year);
        params.setWorkedDays(workedDays);
        params.setTotalWorkDays(totalDays);

        GetService<Payment> service = new GetService<>(Payment.class);
        String responseData = service.sendRequest(RequestType.CALCULATE_SALARY_BULK, params);

        Type listType = new TypeToken<List<Payment>>() {}.getType();
        List<Payment> results = new Gson().fromJson(responseData, listType);

        paymentList.clear();
        if (results != null) {
            paymentList.addAll(results);
            labelStatus.setText("Расчёт завершён. Обработано: " + results.size() + " сотрудников");
        } else {
            labelStatus.setText("Ошибка при расчёте");
        }
    }
}