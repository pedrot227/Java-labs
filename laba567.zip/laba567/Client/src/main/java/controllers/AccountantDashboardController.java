package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class AccountantDashboardController {
    @FXML private Button btnLogout;

    public void openSalaryCalculation(ActionEvent actionEvent) throws IOException {
        loadScene("/SalaryCalculation.fxml");
    }

    public void openPaymentHistory(ActionEvent actionEvent) throws IOException {
        loadScene("/PaymentHistory.fxml");
    }

    public void openReports(ActionEvent actionEvent) throws IOException {
        loadScene("/Report.fxml");
    }

    public void logout(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) btnLogout.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("/Login.fxml"));
        stage.setScene(new Scene(root));
    }

// Внутри AccountantDashboardController.java

    private void loadScene(String fxmlFile) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Панель бухгалтера - Просмотр");

            // Чтобы окно открывалось поверх основного меню
            stage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            stage.show();
        } catch (IOException e) {
            System.err.println("Не удалось открыть окно: " + fxmlFile);
            e.printStackTrace();
        }
    }
}