package controllers;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import main.Enums.RequestType;
import main.Models.Entities.Position;
import main.Utility.GetService;

import java.lang.reflect.Type;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class PositionManagementController implements Initializable {

    @FXML private TableView<Position> tablePositions;
    @FXML private TableColumn<Position, Integer> colId;
    @FXML private TableColumn<Position, String> colName;
    @FXML private TableColumn<Position, Double> colSalary;

    @FXML private TextField txtName, txtSalary;

    private ObservableList<Position> positionList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colName.setCellValueFactory(new PropertyValueFactory<>("positionName"));
        colSalary.setCellValueFactory(new PropertyValueFactory<>("baseSalary"));

        tablePositions.setItems(positionList);
        loadPositions();
    }

    private void loadPositions() {
        GetService<Position> service = new GetService<>(Position.class);
        String response = service.sendRequest(RequestType.GETALL_POSITIONS, null);
        Type listType = new TypeToken<List<Position>>() {}.getType();
        List<Position> list = new Gson().fromJson(response, listType);

        positionList.clear();
        if (list != null) positionList.setAll(list);
    }

    @FXML
    public void addPosition(ActionEvent actionEvent) {
        // 1. Проверяем, не пустые ли поля (чтобы не ловить NumberFormatException)
        if (txtName.getText().trim().isEmpty() || txtSalary.getText().trim().isEmpty()) {
            showAlert("Ошибка", "Все поля должны быть заполнены!");
            return;
        }

        try {
            Position pos = new Position();
            pos.setPositionName(txtName.getText().trim());

            // 2. Пытаемся распарсить число
            pos.setBaseSalary(Double.parseDouble(txtSalary.getText().trim()));

            // 3. Отправляем запрос на сервер
            new GetService<>(Position.class).sendRequest(RequestType.ADD_POSITION, pos);

            // 4. Обновляем таблицу и очищаем поля
            loadPositions();
            txtName.clear();
            txtSalary.clear();

        } catch (NumberFormatException e) {
            // Если вместо цифр ввели буквы
            showAlert("Ошибка ввода", "В поле 'Оклад' должно быть введено число (например, 50000 или 50000.5)");
        }
    }

    // Вспомогательный метод для вывода предупреждений пользователю
    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    @FXML
    public void deletePosition(ActionEvent actionEvent) {
        Position selected = tablePositions.getSelectionModel().getSelectedItem();
        if (selected != null) {
            new GetService<>(Position.class).sendRequest(RequestType.DELETE_POSITION, selected);
            loadPositions();
        }
    }
    @FXML
    public void backToMenu(ActionEvent event) {
        try {
            // Загружаем FXML главного меню админа
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(getClass().getResource("/AdminDashboard.fxml"));
            javafx.scene.Parent root = loader.load();

            // Получаем текущее окно и меняем сцену
            javafx.stage.Stage stage = (javafx.stage.Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setScene(new javafx.scene.Scene(root));
            stage.setTitle("Меню администратора");
            stage.show();
        } catch (java.io.IOException e) {
            System.err.println("Ошибка при возврате в меню: " + e.getMessage());
            e.printStackTrace();
        }
    }
}