package server.DAO;

import server.Models.Entities.Payment;
import server.Utility.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PaymentDAO {
    private static final Logger LOGGER = Logger.getLogger(PaymentDAO.class.getName());

    // ИСПРАВЛЕНО под твою структуру: d.id_department и d.department_name
    private final String BASE_SELECT =
            "SELECT p.*, e.first_name, e.last_name, pos.position_name, d.department_name " +
                    "FROM payments p " +
                    "LEFT JOIN employees e ON p.id_employee = e.id_employee " +
                    "LEFT JOIN positions pos ON e.id_position = pos.id_position " +
                    "LEFT JOIN departments d ON e.id_department = d.id_department ";

    public List<Payment> findAll() {
        List<Payment> list = new ArrayList<>();
        String sql = BASE_SELECT + "ORDER BY p.year DESC, p.month DESC, p.id_payment DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(mapPayment(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка в findAll: проверьте связь таблиц", e);
        }
        return list;
    }

    public Payment findByPeriod(int employeeId, int month, int year) {
        String sql = BASE_SELECT + "WHERE p.id_employee = ? AND p.month = ? AND p.year = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, employeeId);
            stmt.setInt(2, month);
            stmt.setInt(3, year);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapPayment(rs);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка findByPeriod для сотрудника " + employeeId, e);
        }
        return null;
    }

    public List<Payment> findByPeriod(int month, int year) {
        List<Payment> list = new ArrayList<>();
        String sql = BASE_SELECT + "WHERE p.month = ? AND p.year = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, month);
            stmt.setInt(2, year);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) list.add(mapPayment(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка findByPeriod за " + month + "/" + year, e);
        }
        return list;
    }

    public List<Payment> findByUserId(int userId) {
        List<Payment> list = new ArrayList<>();
        String sql = BASE_SELECT + "WHERE e.id_user = ? ORDER BY p.year DESC, p.month DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapPayment(rs));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка findByUserId: " + userId, e);
        }
        return list;
    }

    public void insert(Payment payment) {
        String sql = "INSERT INTO payments (id_employee, month, year, worked_days, total_work_days, " +
                "bonus, total_accrued, pension_contribution, income_tax, tax_deduction, " +
                "net_salary, payment_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) " +
                "ON DUPLICATE KEY UPDATE worked_days=VALUES(worked_days), bonus=VALUES(bonus), " +
                "total_accrued=VALUES(total_accrued), net_salary=VALUES(net_salary), payment_status=VALUES(payment_status)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, payment.getEmployeeId());
            stmt.setInt(2, payment.getMonth());
            stmt.setInt(3, payment.getYear());
            stmt.setInt(4, payment.getWorkedDays());
            stmt.setInt(5, payment.getTotalWorkDays());
            stmt.setDouble(6, payment.getBonus());
            stmt.setDouble(7, payment.getTotalAccrued());
            stmt.setDouble(8, payment.getPensionContribution());
            stmt.setDouble(9, payment.getIncomeTax());
            stmt.setDouble(10, payment.getTaxDeduction());
            stmt.setDouble(11, payment.getNetSalary());
            stmt.setString(12, payment.getPaymentStatus());

            if (stmt.executeUpdate() > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) payment.setId(rs.getInt(1));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка insert payment", e);
        }
    }

    public void update(Payment payment) {
        String sql = "UPDATE payments SET worked_days = ?, total_work_days = ?, bonus = ?, " +
                "total_accrued = ?, pension_contribution = ?, income_tax = ?, " +
                "tax_deduction = ?, net_salary = ?, payment_status = ? " +
                "WHERE id_payment = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, payment.getWorkedDays());
            stmt.setInt(2, payment.getTotalWorkDays());
            stmt.setDouble(3, payment.getBonus());
            stmt.setDouble(4, payment.getTotalAccrued());
            stmt.setDouble(5, payment.getPensionContribution());
            stmt.setDouble(6, payment.getIncomeTax());
            stmt.setDouble(7, payment.getTaxDeduction());
            stmt.setDouble(8, payment.getNetSalary());
            stmt.setString(9, payment.getPaymentStatus());
            stmt.setInt(10, payment.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка update payment ID: " + payment.getId(), e);
        }
    }

    public void updateStatus(int paymentId, String status) {
        String sql = "UPDATE payments SET payment_status = ? WHERE id_payment = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setInt(2, paymentId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка updateStatus", e);
        }
    }

    public void generatePaymentsForMonth(int month, int year) {
        String sql = "INSERT INTO payments (id_employee, month, year, payment_status, total_accrued, net_salary) " +
                "SELECT e.id_employee, ?, ?, 'Рассчитано', 0.0, 0.0 " +
                "FROM employees e " +
                "WHERE e.is_deleted = 0 AND e.id_employee NOT IN (" +
                "  SELECT id_employee FROM payments WHERE month = ? AND year = ?" +
                ")";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, month);
            stmt.setInt(2, year);
            stmt.setInt(3, month);
            stmt.setInt(4, year);
            stmt.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка generatePayments", e);
        }
    }

    private Payment mapPayment(ResultSet rs) throws SQLException {
        Payment p = new Payment();
        p.setId(rs.getInt("id_payment"));
        p.setEmployeeId(rs.getInt("id_employee"));
        p.setMonth(rs.getInt("month"));
        p.setYear(rs.getInt("year"));
        p.setWorkedDays(rs.getInt("worked_days"));
        p.setTotalWorkDays(rs.getInt("total_work_days"));
        p.setBonus(rs.getDouble("bonus"));
        p.setTotalAccrued(rs.getDouble("total_accrued"));
        p.setNetSalary(rs.getDouble("net_salary"));
        p.setPaymentStatus(rs.getString("payment_status"));

        String fName = rs.getString("first_name");
        String lName = rs.getString("last_name");
        p.setEmployeeFullName((lName != null ? lName : "") + " " + (fName != null ? fName : ""));

        p.setPositionName(rs.getString("position_name"));
        p.setDepartmentName(rs.getString("department_name")); // Соответствует SELECT d.department_name
        return p;
    }
}