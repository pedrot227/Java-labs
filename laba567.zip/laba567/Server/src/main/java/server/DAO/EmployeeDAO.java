package server.DAO;

import server.Models.Entities.Employee;
import server.Utility.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EmployeeDAO {
    private static final Logger LOGGER = Logger.getLogger(EmployeeDAO.class.getName());

    public List<Employee> findAll() {
        List<Employee> list = new ArrayList<>();
        // Исправлено: d.id_department, p.id_position, department_name, position_name
        String sql = "SELECT e.*, d.department_name, p.position_name, p.base_salary " +
                "FROM employees e " +
                "LEFT JOIN departments d ON e.id_department = d.id_department " +
                "LEFT JOIN positions p ON e.id_position = p.id_position " +
                "WHERE e.is_deleted = 0";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(mapEmployee(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при получении всех сотрудников", e);
        }
        return list;
    }

    public Employee findById(int id) {
        String sql = "SELECT e.*, d.department_name, p.position_name, p.base_salary " +
                "FROM employees e " +
                "LEFT JOIN departments d ON e.id_department = d.id_department " +
                "LEFT JOIN positions p ON e.id_position = p.id_position " +
                "WHERE e.id_employee = ? AND e.is_deleted = 0";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapEmployee(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при поиске сотрудника по ID: " + id, e);
        }
        return null;
    }

    public void insert(Employee emp) {
        String sql = "INSERT INTO employees (first_name, last_name, hire_date, children_count, " +
                "id_user, id_department, id_position) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, emp.getFirstName());
            stmt.setString(2, emp.getLastName());
            stmt.setString(3, emp.getHireDate());
            stmt.setInt(4, emp.getChildrenCount());
            if (emp.getUserId() > 0) stmt.setInt(5, emp.getUserId()); else stmt.setNull(5, Types.INTEGER);
            if (emp.getDepartmentId() > 0) stmt.setInt(6, emp.getDepartmentId()); else stmt.setNull(6, Types.INTEGER);
            if (emp.getPositionId() > 0) stmt.setInt(7, emp.getPositionId()); else stmt.setNull(7, Types.INTEGER);
            stmt.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при добавлении сотрудника", e);
        }
    }

    public void update(Employee emp) {
        String sql = "UPDATE employees SET first_name=?, last_name=?, hire_date=?, " +
                "children_count=?, id_user=?, id_department=?, id_position=? " +
                "WHERE id_employee=?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, emp.getFirstName());
            stmt.setString(2, emp.getLastName());
            stmt.setString(3, emp.getHireDate());
            stmt.setInt(4, emp.getChildrenCount());
            if (emp.getUserId() > 0) stmt.setInt(5, emp.getUserId()); else stmt.setNull(5, Types.INTEGER);
            if (emp.getDepartmentId() > 0) stmt.setInt(6, emp.getDepartmentId()); else stmt.setNull(6, Types.INTEGER);
            if (emp.getPositionId() > 0) stmt.setInt(7, emp.getPositionId()); else stmt.setNull(7, Types.INTEGER);
            stmt.setInt(8, emp.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при обновлении сотрудника", e);
        }
    }

    public void delete(int id) {
        String sql = "UPDATE employees SET is_deleted = 1 WHERE id_employee = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при удалении сотрудника с ID: " + id, e);
        }
    }

    private Employee mapEmployee(ResultSet rs) throws SQLException {
        Employee emp = new Employee();
        emp.setId(rs.getInt("id_employee"));
        emp.setFirstName(rs.getString("first_name"));
        emp.setLastName(rs.getString("last_name"));
        emp.setHireDate(rs.getString("hire_date"));
        emp.setChildrenCount(rs.getInt("children_count"));
        emp.setUserId(rs.getInt("id_user"));
        emp.setDepartmentId(rs.getInt("id_department"));
        emp.setPositionId(rs.getInt("id_position"));
        emp.setDepartmentName(rs.getString("department_name"));
        emp.setPositionName(rs.getString("position_name"));
        emp.setBaseSalary(rs.getDouble("base_salary"));

        // Теперь метод наследуется от AbstractEntity,
        // поэтому вызываем его напрямую без лишних проверок
        emp.setDeleted(rs.getInt("is_deleted") == 1);

        return emp;
    }
}