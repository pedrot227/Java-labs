package server.DAO;

import server.Models.Entities.Position;
import server.Utility.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PositionDAO {
    private static final Logger LOGGER = Logger.getLogger(PositionDAO.class.getName());

    public List<Position> findAll() {
        List<Position> list = new ArrayList<>();
        // ИЗМЕНЕНО: добавлена фильтрация по флагу удаления
        String sql = "SELECT * FROM positions WHERE is_deleted = 0";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(mapPosition(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при получении списка всех должностей", e);
        }
        return list;
    }

    public void insert(Position pos) {
        String sql = "INSERT INTO positions (position_name, base_salary, hourly_rate) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, pos.getPositionName());
            stmt.setDouble(2, pos.getBaseSalary());
            stmt.setDouble(3, pos.getHourlyRate());
            stmt.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при добавлении должности", e);
        }
    }

    public void update(Position pos) {
        String sql = "UPDATE positions SET position_name=?, base_salary=?, hourly_rate=? WHERE id_position=?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, pos.getPositionName());
            stmt.setDouble(2, pos.getBaseSalary());
            stmt.setDouble(3, pos.getHourlyRate());
            stmt.setInt(4, pos.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при обновлении должности ID: " + pos.getId(), e);
        }
    }

    public void delete(int id) {
        // ИЗМЕНЕНО: вместо физического удаления DELETE используем Soft Delete (UPDATE)
        String sql = "UPDATE positions SET is_deleted = 1 WHERE id_position = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при мягком удалении должности ID: " + id, e);
        }
    }

    private Position mapPosition(ResultSet rs) throws SQLException {
        Position p = new Position();
        p.setId(rs.getInt("id_position")); // Соответствует базе
        p.setPositionName(rs.getString("position_name")); // Соответствует базе
        p.setBaseSalary(rs.getDouble("base_salary"));
        p.setHourlyRate(rs.getDouble("hourly_rate"));
        return p;
    }
}