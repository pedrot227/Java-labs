package server.DAO;

import server.Models.Entities.User;
import server.Utility.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UserDAO {
    private static final Logger LOGGER = Logger.getLogger(UserDAO.class.getName());

    public User findByLoginAndPassword(String login, String password) {
        String sql = "SELECT u.id_user, u.login, u.password_hash, u.id_role, r.role_name " +
                "FROM users u JOIN roles r ON u.id_role = r.id_role " +
                "WHERE u.login = ? AND u.password_hash = ? AND u.is_deleted = 0";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, login);
            stmt.setString(2, password);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapUser(rs, true);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при аутентификации пользователя: " + login, e);
        }
        return null;
    }

    public User findByLogin(String login) {
        String sql = "SELECT u.id_user, u.login, u.password_hash, u.id_role, r.role_name " +
                "FROM users u JOIN roles r ON u.id_role = r.id_role " +
                "WHERE u.login = ? AND u.is_deleted = 0";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, login);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapUser(rs, true);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при поиске пользователя по логину: " + login, e);
        }
        return null;
    }

    // ИЗМЕНЕНО: теперь возвращает ID созданного пользователя
    public int insert(User user) {
        String sql = "INSERT INTO users (login, password_hash, id_role) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, user.getLogin());
            stmt.setString(2, user.getPassword());
            stmt.setInt(3, user.getRoleId() == 0 ? 3 : user.getRoleId());
            stmt.executeUpdate();

            // Получаем сгенерированный ID[cite: 1]
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при регистрации пользователя: " + user.getLogin(), e);
        }
        return -1;
    }

    public List<User> findAll() {
        List<User> users = new ArrayList<>();
        String sql = "SELECT u.id_user, u.login, u.id_role, r.role_name " +
                "FROM users u JOIN roles r ON u.id_role = r.id_role " +
                "WHERE u.is_deleted = 0";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                users.add(mapUser(rs, false));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при получении всех пользователей", e);
        }
        return users;
    }

    public void delete(int id) {
        String sql = "UPDATE users SET is_deleted = 1 WHERE id_user = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при удалении пользователя с ID: " + id, e);
        }
    }

    public void updateRole(int userId, int roleId) {
        String sql = "UPDATE users SET id_role = ? WHERE id_user = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, roleId);
            stmt.setInt(2, userId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при обновлении роли пользователя ID: " + userId, e);
        }
    }

    private User mapUser(ResultSet rs, boolean includePassword) throws SQLException {
        User user = new User();
        user.setId(rs.getInt("id_user"));
        user.setLogin(rs.getString("login"));
        if (includePassword) {
            user.setPassword(rs.getString("password_hash"));
        }
        user.setRoleId(rs.getInt("id_role"));
        user.setRoleName(rs.getString("role_name"));
        return user;
    }
}