package server.DAO;

import server.Models.Entities.Role;
import server.Utility.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RoleDAO {
    private static final Logger LOGGER = Logger.getLogger(RoleDAO.class.getName());

    public List<Role> findAll() {
        List<Role> roles = new ArrayList<>();
        // ИЗМЕНЕНО: добавлена фильтрация активных ролей
        String sql = "SELECT * FROM roles WHERE is_deleted = 0";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                roles.add(mapRole(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при получении списка ролей", e);
        }
        return roles;
    }

    public Role findById(int id) {
        // ИЗМЕНЕНО: поиск только среди не удаленных ролей
        String sql = "SELECT * FROM roles WHERE id_role = ? AND is_deleted = 0";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapRole(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при поиске роли по ID: " + id, e);
        }
        return null;
    }

    // Вспомогательный метод для маппинга (чтобы не дублировать код)
    private Role mapRole(ResultSet rs) throws SQLException {
        Role role = new Role();
        role.setId(rs.getInt("id_role"));
        role.setRoleName(rs.getString("role_name"));
        return role;
    }
}