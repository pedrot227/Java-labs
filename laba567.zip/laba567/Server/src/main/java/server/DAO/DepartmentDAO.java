package server.DAO;

import server.Models.Entities.Department;
import server.Utility.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DepartmentDAO {
    private static final Logger LOGGER = Logger.getLogger(DepartmentDAO.class.getName());

    public List<Department> findAll() {
        List<Department> list = new ArrayList<>();
        // ИЗМЕНЕНО: Добавлен фильтр для получения только активных отделов
        String sql = "SELECT * FROM departments WHERE is_deleted = 0";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(mapDepartment(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при получении списка всех отделов", e);
        }
        return list;
    }

    public Department findById(int id) {
        // ИЗМЕНЕНО: Поиск только среди существующих отделов
        String sql = "SELECT * FROM departments WHERE id_department = ? AND is_deleted = 0";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapDepartment(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при поиске отдела по ID: " + id, e);
        }
        return null;
    }

    public void insert(Department dep) {
        String sql = "INSERT INTO departments (department_name, head_full_name) VALUES (?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, dep.getDepartmentName());
            stmt.setString(2, dep.getHeadFullName());
            stmt.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при добавлении нового отдела", e);
        }
    }

    public void update(Department dep) {
        String sql = "UPDATE departments SET department_name=?, head_full_name=? WHERE id_department=?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, dep.getDepartmentName());
            stmt.setString(2, dep.getHeadFullName());
            stmt.setInt(3, dep.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при обновлении отдела с ID: " + dep.getId(), e);
        }
    }

    public void delete(int id) {
        // ИЗМЕНЕНО: Вместо физического удаления используем UPDATE флага is_deleted
        String sql = "UPDATE departments SET is_deleted = 1 WHERE id_department = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Ошибка при мягком удалении отдела с ID: " + id, e);
        }
    }

    private Department mapDepartment(ResultSet rs) throws SQLException {
        Department d = new Department();
        d.setId(rs.getInt("id_department")); // Имена колонок соответствуют БД
        d.setDepartmentName(rs.getString("department_name"));
        d.setHeadFullName(rs.getString("head_full_name"));
        return d;
    }
}