package server.Utility;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseConnection {
    private static final HikariDataSource dataSource;

    static {
        HikariConfig config = new HikariConfig();
        Properties props = new Properties();
        File configFile = new File("server.properties");

        // Пытаемся загрузить внешний конфиг
        try (InputStream is = configFile.exists()
                ? new FileInputStream(configFile)
                : DatabaseConnection.class.getClassLoader().getResourceAsStream("server.properties")) {

            if (is != null) {
                props.load(is);
            }
        } catch (IOException e) {
            System.err.println("Внешний файл конфигурации не найден, используются настройки по умолчанию.");
        }

        // Настройки подключения (из файла или дефолтные)
        config.setJdbcUrl(props.getProperty("db.url",
                "jdbc:mysql://localhost:3306/salary_system?useUnicode=true&serverTimezone=UTC"));
        config.setUsername(props.getProperty("db.user", "root"));
        config.setPassword(props.getProperty("db.password", "gleb2006912628"));

        // Настройки пула
        config.setMaximumPoolSize(Integer.parseInt(props.getProperty("db.pool.max", "10")));
        config.setMinimumIdle(Integer.parseInt(props.getProperty("db.pool.idle", "2")));
        config.setIdleTimeout(300000);
        config.setConnectionTimeout(20000);

        // Оптимизация для MySQL (оставляем без изменений)
        config.addDataSourceProperty("cachePrepStmts", "true");
        config.addDataSourceProperty("prepStmtCacheSize", "250");
        config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");

        dataSource = new HikariDataSource(config);
    }

    public static Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    public static void shutdown() {
        if (dataSource != null) {
            dataSource.close();
        }
    }
}