package server.Models.Entities;

/**
 * Класс сущности "Бухгалтер".
 * Наследуется от User для расширения иерархии (9-й класс).
 */
public class Accountant extends User {

    public Accountant() {
        super();
    }

    public Accountant(int id, String login, String password, int roleId) {
        super(id, login, password, roleId);
    }

    @Override
    public String toString() {
        return "Бухгалтер: " + getLogin();
    }
}