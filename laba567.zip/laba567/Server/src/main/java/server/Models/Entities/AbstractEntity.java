package server.Models.Entities;



import java.io.Serializable;



/**

 * Абстрактный базовый класс для всех сущностей системы.

 * Обеспечивает сериализацию и хранение общего идентификатора.

 */

public abstract class AbstractEntity implements Serializable {

// Поле ID общее для всех таблиц вашей БД (users, employees, payments и т.д.)

    protected int id;

    protected boolean isDeleted; // Добавлено общее поле

    public AbstractEntity() {}



    public AbstractEntity(int id) {

        this.id = id;

    }

    public boolean isDeleted() { return isDeleted; }

    public void setDeleted(boolean deleted) { isDeleted = deleted; }

    public int getId() {

        return id;

    }



    public void setId(int id) {

        this.id = id;

    }

}