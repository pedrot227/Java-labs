package server.Models.Entities;

import java.io.Serializable;

/**
 * Класс User, интегрированный в иерархию сущностей.
 */
public class User extends AbstractEntity implements Serializable {
    private String login;
    private String password;
    private int roleId;
    private String roleName;


    public User() {
        super();
    }

    public User(int id, String login, String password, int roleId) {
        super(id); // Лучше использовать конструктор родителя, если он есть
        this.login = login;
        this.password = password;
        this.roleId = roleId;
    }

    // Геттеры и сеттеры
    public String getLogin() { return login; }
    public void setLogin(String login) { this.login = login; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public int getRoleId() { return roleId; }
    public void setRoleId(int roleId) { this.roleId = roleId; }

    public String getRoleName() { return roleName; }
    public void setRoleName(String roleName) { this.roleName = roleName; }


}