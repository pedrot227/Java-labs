package server.Models.Entities;

public class Employee extends AbstractEntity {
    private String firstName;
    private String lastName;
    private String hireDate;
    private int childrenCount;
    private int userId;
    private int departmentId;
    private int positionId;
    private String login;
    private String password;

    private String departmentName;
    private String positionName;
    private double baseSalary;

    public Employee() { super(); }

    public Employee(int id, String firstName, String lastName, String hireDate,
                    int childrenCount, int userId, int departmentId, int positionId) {
        super(id);
        this.firstName = firstName;
        this.lastName = lastName;
        this.hireDate = hireDate;
        this.childrenCount = childrenCount;
        this.userId = userId;
        this.departmentId = departmentId;
        this.positionId = positionId;
    }



    // Остальные геттеры/сеттеры без изменений
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }
    public String getHireDate() { return hireDate; }
    public void setHireDate(String hireDate) { this.hireDate = hireDate; }
    public int getChildrenCount() { return childrenCount; }
    public void setChildrenCount(int childrenCount) { this.childrenCount = childrenCount; }
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public int getDepartmentId() { return departmentId; }
    public void setDepartmentId(int departmentId) { this.departmentId = departmentId; }
    public int getPositionId() { return positionId; }
    public void setPositionId(int positionId) { this.positionId = positionId; }
    public String getDepartmentName() { return departmentName; }
    public void setDepartmentName(String departmentName) { this.departmentName = departmentName; }
    public String getPositionName() { return positionName; }
    public void setPositionName(String positionName) { this.positionName = positionName; }
    public double getBaseSalary() { return baseSalary; }
    public void setBaseSalary(double baseSalary) { this.baseSalary = baseSalary; }
    public String getLogin() { return login; }
    public void setLogin(String login) { this.login = login; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getFullName() {
        return (lastName != null ? lastName : "") + " " + (firstName != null ? firstName : "");
    }

}