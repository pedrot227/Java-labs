package server.Services;

import server.Models.Entities.Admin;
import server.Models.Entities.Accountant;
import com.google.gson.Gson;
import server.DAO.UserDAO;
import server.Models.Entities.User;
import server.Models.TCP.Response;
import server.Enums.ResponseStatus;

public class AuthService {
    private UserDAO userDAO = new UserDAO();
    private Gson gson = new Gson();

    /**
     * Обработка входа пользователя в систему
     */
    public Response login(String message) {
        User user = gson.fromJson(message, User.class);
        User found = userDAO.findByLoginAndPassword(user.getLogin(), user.getPassword());

        Response response = new Response();
        if (found != null) {
            User roleSpecificUser;

            // ВАЖНО: Проверь ID ролей в своей БД. Обычно 1 - Админ, 2 - Бухгалтер.
            if (found.getRoleId() == 1) {
                roleSpecificUser = new Admin(found.getId(), found.getLogin(), found.getPassword(), found.getRoleId());
                roleSpecificUser.setRoleName("Администратор");
            } else if (found.getRoleId() == 2) {
                roleSpecificUser = new Accountant(found.getId(), found.getLogin(), found.getPassword(), found.getRoleId());
                roleSpecificUser.setRoleName("Бухгалтер");
            } else {
                roleSpecificUser = found;
                // Если это обычный сотрудник, убедимся, что имя роли не null
                if (roleSpecificUser.getRoleName() == null) {
                    roleSpecificUser.setRoleName("Сотрудник");
                }
            }

            response.setResponseStatus(ResponseStatus.OK);
            response.setResponseData(gson.toJson(roleSpecificUser));
        } else {
            response.setResponseStatus(ResponseStatus.ERROR);
            response.setResponseMessage("Неверный логин или пароль");
        }
        return response;
    }

    /**
     * Регистрация нового пользователя с проверкой на уникальность логина
     */
    public Response register(String message) {
        User user = gson.fromJson(message, User.class);
        Response response = new Response();

        // Проверяем, существует ли уже такой логин
        if (userDAO.findByLogin(user.getLogin()) != null) {
            response.setResponseStatus(ResponseStatus.ERROR);
            response.setResponseMessage("Логин занят");
        } else {
            userDAO.insert(user);
            response.setResponseStatus(ResponseStatus.OK);
        }
        return response;
    }
}