package server.Services;

import com.google.gson.Gson;
import server.DAO.PaymentDAO;
import server.Models.Entities.Payment;
import server.Models.TCP.Response;
import server.Enums.ResponseStatus;
import java.util.List;

public class PaymentService {
    private PaymentDAO paymentDAO = new PaymentDAO();
    private Gson gson = new Gson();

    public Response getAllPayments() {
        Response response = new Response();
        response.setResponseStatus(ResponseStatus.OK);
        response.setResponseData(gson.toJson(paymentDAO.findAll()));
        return response;
    }

    public Response getPaymentsByPeriod(String message) {
        // Извлекаем месяц и год из пришедшего JSON
        Payment params = gson.fromJson(message, Payment.class);

        // В PaymentDAO должен быть перегруженный метод findByPeriod(int month, int year)
        // который возвращает List<Payment>
        List<Payment> list = paymentDAO.findByPeriod(params.getMonth(), params.getYear());

        Response response = new Response();
        response.setResponseStatus(ResponseStatus.OK);
        response.setResponseData(gson.toJson(list));
        return response;
    }

    public Response getPaymentsByEmployee(String message) {
        // 1. Десериализуем пришедшее сообщение в объект Employee
        server.Models.Entities.Employee emp = gson.fromJson(message, server.Models.Entities.Employee.class);

        // 2. Достаем ID (теперь это безопасно)
        int userId = emp.getId();

        Response response = new Response();
        response.setResponseStatus(ResponseStatus.OK);

        // 3. Отправляем список выплат обратно в формате JSON
        response.setResponseData(gson.toJson(paymentDAO.findByUserId(userId)));
        return response;
    }
}