package server.Services;

import com.google.gson.Gson;
import server.DAO.EmployeeDAO;
import server.DAO.UserDAO;
import server.Models.Entities.Employee;
import server.Models.Entities.User;
import server.Models.TCP.Response;
import server.Enums.ResponseStatus;
import java.util.logging.Logger;

public class EmployeeService {
    private static final Logger LOGGER = Logger.getLogger(EmployeeService.class.getName());
    private EmployeeDAO employeeDAO = new EmployeeDAO();
    private UserDAO userDAO = new UserDAO(); // Добавлено для работы с пользователями
    private Gson gson = new Gson();

    public Response getAllEmployees() {
        Response response = new Response();
        response.setResponseStatus(ResponseStatus.OK);
        response.setResponseData(gson.toJson(employeeDAO.findAll()));
        return response;
    }

    public Response addEmployee(String message) {
        Response response = new Response();
        try {
            Employee emp = gson.fromJson(message, Employee.class);

            // 1. Сначала создаем учетную запись пользователя
            User newUser = new User();
            newUser.setLogin(emp.getLogin());
            newUser.setPassword(emp.getPassword());
            // Если нужно создавать бухгалтера, логика выбора роли должна быть здесь
            newUser.setRoleId(3); // По умолчанию роль "Сотрудник"

            int generatedUserId = userDAO.insert(newUser);

            if (generatedUserId != -1) {
                // 2. Привязываем полученный ID пользователя к сотруднику[cite: 1]
                emp.setUserId(generatedUserId);

                // Проверка формата даты (ваша существующая логика)
                if (emp.getHireDate() != null && emp.getHireDate().length() == 4) {
                    emp.setHireDate(emp.getHireDate() + "-01-01");
                }

                // 3. Сохраняем сотрудника в БД
                employeeDAO.insert(emp);
                response.setResponseStatus(ResponseStatus.OK);
            } else {
                LOGGER.severe("Не удалось создать пользователя для сотрудника");
                response.setResponseStatus(ResponseStatus.ERROR);
            }
        } catch (Exception e) {
            LOGGER.severe("Ошибка в EmployeeService.addEmployee: " + e.getMessage());
            response.setResponseStatus(ResponseStatus.ERROR);
        }
        return response;
    }

    public Response updateEmployee(String message) {
        Employee emp = gson.fromJson(message, Employee.class);
        // Проверка даты при обновлении
        if (emp.getHireDate() != null && emp.getHireDate().length() == 4) {
            emp.setHireDate(emp.getHireDate() + "-01-01");
        }
        employeeDAO.update(emp);
        Response response = new Response();
        response.setResponseStatus(ResponseStatus.OK);
        return response;
    }

    public Response deleteEmployee(String message) {
        Employee emp = gson.fromJson(message, Employee.class);
        employeeDAO.delete(emp.getId());
        Response response = new Response();
        response.setResponseStatus(ResponseStatus.OK);
        return response;
    }
}