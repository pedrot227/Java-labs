package server.Services;

import server.Models.Entities.Employee;
import server.Models.Entities.Payment;
import server.DAO.EmployeeDAO;
import server.DAO.PaymentDAO;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class SalaryCalculationService {

    private final EmployeeDAO employeeDAO = new EmployeeDAO();
    private final PaymentDAO paymentDAO = new PaymentDAO();

    // Налоговые константы РБ
    private static final double PENSION_RATE = 0.01;
    private static final double INCOME_TAX_RATE = 0.13;
    private static final double STANDARD_DEDUCTION = 156.0;
    private static final double CHILD_DEDUCTION = 46.0;
    private static final double MAX_INCOME_FOR_DEDUCTION = 944.0;

    public Payment calculateForEmployee(int employeeId, int month, int year,
                                        int workedDays, int totalWorkDays, double bonus) {

        Employee emp = employeeDAO.findById(employeeId);

        if (emp == null) {
            System.err.println("ERROR: Сотрудник с ID " + employeeId + " не найден в БД!");
            return null;
        }

        double baseSalary = emp.getBaseSalary();
        System.out.println(String.format("DEBUG [%s]: Оклад=%f, Отр.дни=%d, Норма=%d",
                emp.getLastName(), baseSalary, workedDays, totalWorkDays));
        if (totalWorkDays <= 0) totalWorkDays = 22;
        double actualSalary = baseSalary * ((double) workedDays / totalWorkDays);
        double totalAccrued = actualSalary + bonus;
        double pensionContribution = Math.round(totalAccrued * PENSION_RATE * 100.0) / 100.0;
        double taxBase = totalAccrued - pensionContribution;
        double totalDeduction = (taxBase <= MAX_INCOME_FOR_DEDUCTION ? STANDARD_DEDUCTION : 0)
                + (emp.getChildrenCount() * CHILD_DEDUCTION);

        double taxableBase = Math.max(0, taxBase - totalDeduction);
        double incomeTax = Math.round(taxableBase * INCOME_TAX_RATE * 100.0) / 100.0;
        double netSalary = Math.round((totalAccrued - pensionContribution - incomeTax) * 100.0) / 100.0;

        Payment payment = new Payment();
        payment.setEmployeeId(employeeId);
        payment.setMonth(month);
        payment.setYear(year);
        payment.setWorkedDays(workedDays);
        payment.setTotalWorkDays(totalWorkDays);
        payment.setBonus(bonus);
        payment.setTotalAccrued(Math.round(totalAccrued * 100.0) / 100.0);
        payment.setPensionContribution(pensionContribution);
        payment.setIncomeTax(incomeTax);
        payment.setTaxDeduction(Math.round(totalDeduction * 100.0) / 100.0);
        payment.setNetSalary(netSalary);
        payment.setPaymentStatus("Рассчитано");

        String fullName = (emp.getLastName() != null ? emp.getLastName() : "") + " " +
                (emp.getFirstName() != null ? emp.getFirstName() : "");
        payment.setEmployeeFullName(fullName.trim());
        payment.setPositionName(emp.getPositionName());
        payment.setDepartmentName(emp.getDepartmentName());

        // Запись в БД
        synchronized (this) {
            Payment existing = paymentDAO.findByPeriod(employeeId, month, year);
            if (existing != null) {
                payment.setId(existing.getId());
                paymentDAO.update(payment);
            } else {
                paymentDAO.insert(payment);
            }
        }
        return payment;
    }

    public List<Payment> calculateBulk(Payment inputParams) {
        List<Employee> targetEmployees = (inputParams.getEmployeeId() > 0)
                ? List.of(employeeDAO.findById(inputParams.getEmployeeId()))
                : employeeDAO.findAll();

        if (targetEmployees.isEmpty()) return new ArrayList<>();

        // Ограничиваем количество потоков
        int threadCount = Math.min(targetEmployees.size(), Runtime.getRuntime().availableProcessors());
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        List<Future<Payment>> futures = new ArrayList<>();

        for (Employee emp : targetEmployees) {
            Callable<Payment> task = () -> calculateForEmployee(
                    emp.getId(),
                    inputParams.getMonth(),
                    inputParams.getYear(),
                    inputParams.getWorkedDays(),
                    inputParams.getTotalWorkDays(),
                    inputParams.getBonus()
            );
            futures.add(executor.submit(task));
        }

        List<Payment> results = new ArrayList<>();
        for (Future<Payment> future : futures) {
            try {
                Payment res = future.get(10, TimeUnit.SECONDS);
                if (res != null) results.add(res);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        executor.shutdown();
        return results;
    }

    // Перегруженный метод для вызова из ClientHandler
    public List<Payment> calculateBulk(int month, int year, int workedDays, int totalWorkDays) {
        Payment p = new Payment();
        p.setMonth(month);
        p.setYear(year);
        p.setWorkedDays(workedDays);
        p.setTotalWorkDays(totalWorkDays);
        p.setBonus(0); // По умолчанию без премии
        return calculateBulk(p);
    }
}