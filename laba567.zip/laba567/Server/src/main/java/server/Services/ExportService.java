package server.Services;

import server.Models.Entities.Payment;
import server.DAO.PaymentDAO;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class ExportService {

    private final PaymentDAO paymentDAO = new PaymentDAO();

    /**
     * Генерирует индивидуальный расчетный листок в формате .txt
     */
    public String exportPaySlip(int employeeId, int month, int year) {
        // ОПТИМИЗАЦИЯ: Используем новый метод DAO для получения конкретной записи напрямую из БД
        Payment p = paymentDAO.findByPeriod(employeeId, month, year);

        if (p == null) return "Данные для расчета не найдены.";

        String fileName = "PaySlip_" + employeeId + "_" + month + "_" + year + ".txt";

        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
            writer.println("========================================");
            writer.println("       РАСЧЕТНЫЙ ЛИСТОК (SalarySystem)  ");
            writer.println("========================================");
            writer.println("Период: " + String.format("%02d", p.getMonth()) + "." + p.getYear());
            writer.println("Сотрудник: " + p.getEmployeeFullName());
            writer.println("Отдел: " + p.getDepartmentName());
            writer.println("Должность: " + p.getPositionName());
            writer.println("----------------------------------------");
            writer.println("Отработано дней: " + p.getWorkedDays() + "/" + p.getTotalWorkDays());
            writer.println("Начислено (всего): " + p.getTotalAccrued() + " BYN");
            writer.println("  - в т.ч. премия: " + p.getBonus() + " BYN");
            writer.println("----------------------------------------");
            writer.println("Удержания:");
            writer.println("  - Пенсионный взнос (1%): " + p.getPensionContribution() + " BYN");
            writer.println("  - Подоходный налог (13%): " + p.getIncomeTax() + " BYN");
            writer.println("Налоговый вычет: " + p.getTaxDeduction() + " BYN");
            writer.println("----------------------------------------");
            writer.println("К ВЫПЛАТЕ: " + p.getNetSalary() + " BYN");
            writer.println("Статус: " + p.getPaymentStatus());
            writer.println("========================================");

            return "Отчет успешно сформирован: " + fileName;
        } catch (IOException e) {
            e.printStackTrace();
            return "Ошибка при записи файла: " + e.getMessage();
        }
    }


    /**
     * Генерирует сводную ведомость за месяц в формате .csv
     */
    public String exportMonthlyReport(int month, int year) {
        // ИСПРАВЛЕНО: Измените findAllByPeriod на findByPeriod
        List<Payment> payments = paymentDAO.findByPeriod(month, year);

        if (payments.isEmpty()) return "Нет данных за указанный период.";

        String fileName = "Report_" + month + "_" + year + ".csv";

        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
            writer.write('\ufeff');
            writer.println("Сотрудник;Отдел;Должность;Начислено;Удержано;К выдаче;Статус");

            for (Payment p : payments) {
                double totalTaxes = p.getPensionContribution() + p.getIncomeTax();
                writer.printf("%s;%s;%s;%.2f;%.2f;%.2f;%s\n",
                        p.getEmployeeFullName(),
                        p.getDepartmentName(),
                        p.getPositionName(),
                        p.getTotalAccrued(),
                        totalTaxes,
                        p.getNetSalary(),
                        p.getPaymentStatus()
                );
            }
            return "Сводный отчет сформирован: " + fileName;
        } catch (IOException e) {
            e.printStackTrace();
            return "Ошибка при формировании ведомости: " + e.getMessage();
        }
    }
}