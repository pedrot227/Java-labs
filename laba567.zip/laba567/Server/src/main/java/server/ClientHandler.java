package server;

import static server.Enums.RequestType.*;
import com.google.gson.Gson;
import server.Enums.ResponseStatus;
import server.Models.Entities.*;
import server.Models.TCP.Request;
import server.Models.TCP.Response;
import server.DAO.*;
import server.Services.*;
import java.util.List;

import java.io.*;
import java.net.Socket;

public class ClientHandler implements Runnable {
    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private final Gson gson = new Gson();

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        String threadName = Thread.currentThread().getName();
        System.out.println("[" + threadName + "] Начата обработка клиента: " + socket.getInetAddress());

        try {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                Request request = gson.fromJson(inputLine, Request.class);
                Response response = handleRequest(request);

                out.println(gson.toJson(response));
                out.flush();
            }
        } catch (IOException e) {
            System.out.println("[" + threadName + "] Соединение потеряно: " + e.getMessage());
        } finally {
            closeResources(threadName);
        }
    }

    private void closeResources(String threadName) {
        try {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("[" + threadName + "] Ресурсы очищены.");
    }

    private Response handleRequest(Request request) {
        // Инициализация сервисов
        AuthService authService = new AuthService();
        EmployeeService employeeService = new EmployeeService();
        PaymentService paymentService = new PaymentService();
        SalaryCalculationService calcService = new SalaryCalculationService();
        ExportService exportService = new ExportService();

        try {
            switch (request.getRequestType()) {
                // ===== АВТОРИЗАЦИЯ =====
                case LOGIN:
                    return authService.login(request.getRequestMessage());
                case REGISTER:
                    return authService.register(request.getRequestMessage());

                // ===== СОТРУДНИКИ =====
                case GETALL_EMPLOYEES:
                    return employeeService.getAllEmployees();
                case ADD_EMPLOYEE:
                    return employeeService.addEmployee(request.getRequestMessage());
                case UPDATE_EMPLOYEE:
                    return employeeService.updateEmployee(request.getRequestMessage());
                case DELETE_EMPLOYEE:
                    return employeeService.deleteEmployee(request.getRequestMessage());

                // ===== ВЫПЛАТЫ И ИСТОРИЯ =====
                case GETALL_PAYMENTS:
                    return paymentService.getAllPayments();
                case GET_PAYMENTS_BY_PERIOD:
                    return paymentService.getPaymentsByPeriod(request.getRequestMessage());
                case GET_PAYMENTS_BY_EMPLOYEE:
                    return paymentService.getPaymentsByEmployee(request.getRequestMessage());
                case UPDATE_PAYMENT_STATUS: {
                    Payment p = gson.fromJson(request.getRequestMessage(), Payment.class);
                    new PaymentDAO().updateStatus(p.getId(), p.getPaymentStatus());
                    return new Response(ResponseStatus.OK, "Статус обновлен");
                }
                case GENERATE_PAYMENTS: {
                    Payment p = gson.fromJson(request.getRequestMessage(), Payment.class);
                    PaymentDAO dao = new PaymentDAO();
                    dao.generatePaymentsForMonth(p.getMonth(), p.getYear());
                    return new Response(ResponseStatus.OK, gson.toJson(dao.findAll()));
                }

                // ===== ОТДЕЛЫ =====
                case ADD_DEPARTMENT: {
                    Department dep = gson.fromJson(request.getRequestMessage(), Department.class);
                    new DepartmentDAO().insert(dep);
                    return new Response(ResponseStatus.OK, "Отдел добавлен");
                }
                case DELETE_DEPARTMENT: {
                    Department dep = gson.fromJson(request.getRequestMessage(), Department.class);
                    new DepartmentDAO().delete(dep.getId());
                    return new Response(ResponseStatus.OK, "Отдел удален");
                }
                case GETALL_DEPARTMENTS: {
                    return new Response(ResponseStatus.OK, gson.toJson(new DepartmentDAO().findAll()));
                }

                // ===== ДОЛЖНОСТИ =====
                case ADD_POSITION: {
                    Position pos = gson.fromJson(request.getRequestMessage(), Position.class);
                    new PositionDAO().insert(pos);
                    return new Response(ResponseStatus.OK, "Должность добавлена");
                }
                case DELETE_POSITION: {
                    Position pos = gson.fromJson(request.getRequestMessage(), Position.class);
                    new PositionDAO().delete(pos.getId());
                    return new Response(ResponseStatus.OK, "Должность удалена");
                }
                case GETALL_POSITIONS: {
                    return new Response(ResponseStatus.OK, gson.toJson(new PositionDAO().findAll()));
                }

                // ===== РАСЧЕТЫ =====
                case CALCULATE_SALARY_BULK: {
                    Payment p = gson.fromJson(request.getRequestMessage(), Payment.class);
                    // Вызываем расчет. Сервис сам выполнит сохранение в БД (через paymentDAO.insert)
                    List<Payment> results = calcService.calculateBulk(p.getMonth(), p.getYear(), p.getWorkedDays(), p.getTotalWorkDays());
                    return new Response(ResponseStatus.OK, gson.toJson(results));
                }

                // ===== ПОЛЬЗОВАТЕЛИ =====
                case GETALL_USERS: {
                    return new Response(ResponseStatus.OK, gson.toJson(new UserDAO().findAll()));
                }

                // ===== ОТЧЕТЫ (ЭКСПОРТ) =====
                case GENERATE_MONTHLY_REPORT: {
                    Payment p = gson.fromJson(request.getRequestMessage(), Payment.class);
                    String reportPath = exportService.exportMonthlyReport(p.getMonth(), p.getYear());
                    return new Response(ResponseStatus.OK, reportPath);
                }

                default: {
                    return new Response(ResponseStatus.ERROR, "Неизвестная команда: " + request.getRequestType());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new Response(ResponseStatus.ERROR, "Ошибка сервера: " + e.getMessage());
        }
    }
}