package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server {
    private static final int PORT = 5555;
    // Используем пул потоков для контроля ресурсов (напр., максимум 10 одновременных клиентов)
    private static final int THREAD_POOL_SIZE = 10;

    public static void main(String[] args) {
        System.out.println("Сервер запущен на порту " + PORT);
        ExecutorService threadPool = Executors.newFixedThreadPool(THREAD_POOL_SIZE);

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {

            // Бесконечный цикл для постоянного ожидания новых подключений
            while (true) {
                Socket socket = serverSocket.accept();

                // Выводим только факт подключения, без привязки к потоку,
                // так как здесь мы еще в main-потоке.
                System.out.println("Подключен новый клиент: " + socket.getInetAddress());

                // Передаем задачу в пул потоков
                ClientHandler handler = new ClientHandler(socket);
                threadPool.execute(handler);
            }
        } catch (IOException e) {
            System.err.println("Фатальная ошибка сервера: " + e.getMessage());
        } finally {
            threadPool.shutdown();
            System.out.println("Сервер остановлен.");
        }
    }
}