package server.Enums;

public enum RequestType {
    // ===== АВТОРИЗАЦИЯ И ПОЛЬЗОВАТЕЛИ =====
    LOGIN,
    REGISTER,
    GETALL_USERS,
    UPDATE_USER_ROLE,
    DELETE_USER,

    // ===== СОТРУДНИКИ =====
    ADD_EMPLOYEE,
    UPDATE_EMPLOYEE,
    DELETE_EMPLOYEE,
    GET_EMPLOYEE,
    GETALL_EMPLOYEES,

    // ===== ОТДЕЛЫ =====
    GETALL_DEPARTMENTS,
    ADD_DEPARTMENT,
    UPDATE_DEPARTMENT,
    DELETE_DEPARTMENT,

    // ===== ДОЛЖНОСТИ =====
    GETALL_POSITIONS,
    ADD_POSITION,
    UPDATE_POSITION,
    DELETE_POSITION,

    // ===== РАСЧЁТЫ И ВЫПЛАТЫ =====
    CALCULATE_SALARY,
    CALCULATE_SALARY_BULK,
    GETALL_PAYMENTS,
    GET_PAYMENTS_BY_EMPLOYEE,
    GET_PAYMENTS_BY_PERIOD,
    UPDATE_PAYMENT_STATUS,

    // ===== ОТЧЁТЫ И АНАЛИТИКА =====
    GENERATE_PAY_SLIP,        // Индивидуальный листок
    GENERATE_MONTHLY_REPORT,  // Сводная ведомость
    GET_PAYROLL_SUMMARY,      // Общая статистика
    EXPORT_CSV,               // Экспорт в CSV
    FORECAST_PAYROLL,
    GENERATE_PAYMENTS// Прогнозирование (на будущее)
}