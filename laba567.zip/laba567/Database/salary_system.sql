-- salary_system.sql

DROP DATABASE IF EXISTS salary_system;
CREATE DATABASE salary_system DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE salary_system;

-- 1. Роли
CREATE TABLE roles (
                       id_role INT AUTO_INCREMENT PRIMARY KEY,
                       role_name VARCHAR(50) NOT NULL UNIQUE
);

-- 2. Пользователи
CREATE TABLE users (
                       id_user INT AUTO_INCREMENT PRIMARY KEY,
                       login VARCHAR(100) NOT NULL UNIQUE,
                       password_hash VARCHAR(255) NOT NULL,
                       id_role INT NOT NULL,
                       FOREIGN KEY (id_role) REFERENCES roles(id_role)
                           ON DELETE RESTRICT ON UPDATE CASCADE
);

-- 3. Должности
CREATE TABLE positions (
                           id_position INT AUTO_INCREMENT PRIMARY KEY,
                           position_name VARCHAR(100) NOT NULL,
                           base_salary DECIMAL(10,2) NOT NULL DEFAULT 0,
                           hourly_rate DECIMAL(10,2) NOT NULL DEFAULT 0
);

-- 4. Отделы
CREATE TABLE departments (
                             id_department INT AUTO_INCREMENT PRIMARY KEY,
                             department_name VARCHAR(100) NOT NULL,
                             head_full_name VARCHAR(200)
);

-- 5. Сотрудники
CREATE TABLE employees (
                           id_employee INT AUTO_INCREMENT PRIMARY KEY,
                           first_name VARCHAR(100) NOT NULL,
                           last_name VARCHAR(100) NOT NULL,
                           hire_date DATE NOT NULL,
                           children_count INT NOT NULL DEFAULT 0,
                           id_user INT,
                           id_department INT,
                           id_position INT,
                           FOREIGN KEY (id_user) REFERENCES users(id_user)
                               ON DELETE SET NULL ON UPDATE CASCADE,
                           FOREIGN KEY (id_department) REFERENCES departments(id_department)
                               ON DELETE SET NULL ON UPDATE CASCADE,
                           FOREIGN KEY (id_position) REFERENCES positions(id_position)
                               ON DELETE SET NULL ON UPDATE CASCADE
);

-- 6. Выплаты
CREATE TABLE payments (
                          id_payment INT AUTO_INCREMENT PRIMARY KEY,
                          id_employee INT NOT NULL,
                          month INT NOT NULL,
                          year INT NOT NULL,
                          worked_days INT NOT NULL DEFAULT 0,
                          total_work_days INT NOT NULL DEFAULT 22,
                          bonus DECIMAL(10,2) NOT NULL DEFAULT 0,
                          total_accrued DECIMAL(10,2) NOT NULL DEFAULT 0,
                          pension_contribution DECIMAL(10,2) NOT NULL DEFAULT 0,
                          income_tax DECIMAL(10,2) NOT NULL DEFAULT 0,
                          tax_deduction DECIMAL(10,2) NOT NULL DEFAULT 0,
                          net_salary DECIMAL(10,2) NOT NULL DEFAULT 0,
                          payment_status VARCHAR(50) NOT NULL DEFAULT 'Ожидание',
                          FOREIGN KEY (id_employee) REFERENCES employees(id_employee)
                              ON DELETE CASCADE ON UPDATE CASCADE,
                          UNIQUE KEY unique_emp_period (id_employee, month, year)
);

-- Начальные данные
INSERT INTO roles (role_name) VALUES ('Администратор'), ('Бухгалтер'), ('Сотрудник');

INSERT INTO users (login, password_hash, id_role) VALUES
                                                      ('admin', 'admin123', 1),
                                                      ('accountant', 'acc123', 2),
                                                      ('employee1', 'emp123', 3);

INSERT INTO departments (department_name, head_full_name) VALUES
                                                              ('IT-отдел', 'Петров П.П.'),
                                                              ('Бухгалтерия', 'Сидорова А.А.'),
                                                              ('Отдел продаж', 'Козлов К.К.');

INSERT INTO positions (position_name, base_salary, hourly_rate) VALUES
                                                                    ('Программист', 3000.00, 17.05),
                                                                    ('Бухгалтер', 2500.00, 14.20),
                                                                    ('Менеджер по продажам', 2200.00, 12.50),
                                                                    ('Системный администратор', 2800.00, 15.90),
                                                                    ('Руководитель отдела', 4000.00, 22.73);

INSERT INTO employees (first_name, last_name, hire_date, children_count, id_user, id_department, id_position) VALUES
                                                                                                                  ('Иван', 'Иванов', '2023-01-15', 1, 3, 1, 1),
                                                                                                                  ('Мария', 'Сидорова', '2022-06-01', 0, NULL, 2, 2),
                                                                                                                  ('Алексей', 'Козлов', '2024-03-10', 2, NULL, 3, 3);